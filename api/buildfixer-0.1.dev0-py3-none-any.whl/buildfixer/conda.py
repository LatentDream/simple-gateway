# taken from https://github.com/ploomber/k2s/blob/main/src/k2s/index.py
from datetime import datetime
from enum import Enum
import os
import urllib.request
from pathlib import Path
import json
from typing import List, Dict
import yaml
from itertools import chain


from buildfixer.requirements import ParsedRequirement

# To not re-download at runtime - 2x ~300MB of data
BLOCK_REDOWNDLOAD = bool(os.environ.get('BLOCK_REDOWNDLOAD'))

class Architecture(Enum):
    NOARCH = "noarch"
    LINUX_64 = "linux-64"
    LINUX_ARM64 = "linux-aarch64"
    LINUX_PPC64LE = "linux-ppc64le"
    OSX_64 = "osx-64"
    OSX_ARM64 = "osx-arm64"
    WIN_64 = "win-64"


class CondaForgeData:
    """Get conda-forge channel data"""

    def __init__(self, architecture: Architecture):
        self._home = Path("~", ".buildfixer").expanduser()
        self._home.mkdir(exist_ok=True, parents=True)
        self._architecture = architecture
        self._ingest_data()

    def _load_conda_forge_data_for_architecture(
        self, architecture: Architecture, force_download: bool = False
    ):
        self._home.mkdir(exist_ok=True, parents=True)

        target = self._home / f"{architecture.value}-conda-forge.json"

        current_time = datetime.now()

        SECONDS_IN_A_WEEK = 604_800

        should_download = (
            force_download
            or not target.exists()
            or (
                (
                    current_time - datetime.fromtimestamp(target.stat().st_mtime)
                ).total_seconds()
                > SECONDS_IN_A_WEEK
                and not BLOCK_REDOWNDLOAD
            )
        )

        if should_download:
            # TODO: add retry logic, and a lock to prevent multiple instances from downloading
            # the same data
            urllib.request.urlretrieve(
                f"https://conda.anaconda.org/conda-forge/{architecture.value}/repodata.json",
                target,
            )
            data = json.loads(target.read_text())
        else:
            data = None

        return should_download, data

    # TODO: we need to ensure that it has the data for the current architecture
    def _ingest_data(self):
        import sqlite3

        downloaded_noarch, data_noarch = self._load_conda_forge_data_for_architecture(
            Architecture.NOARCH
        )

        downloaded_architecture, data_architecture = (
            self._load_conda_forge_data_for_architecture(self._architecture)
        )

        path_to_db = self._home / "conda-forge.db"
        conn = sqlite3.connect(path_to_db)

        # should I check for an empty table?
        table_exists = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='packages'"
        ).fetchone()

        if downloaded_noarch or downloaded_architecture or not table_exists:

            if not downloaded_noarch:
                _, data_noarch = self._load_conda_forge_data_for_architecture(
                    Architecture.NOARCH,
                    force_download=True,
                )

            if not downloaded_architecture:
                _, data_architecture = self._load_conda_forge_data_for_architecture(
                    self._architecture,
                    force_download=True,
                )

            cursor = conn.cursor()

            cursor.execute("DROP TABLE IF EXISTS packages")
            cursor.execute(
                """
                CREATE TABLE packages (name TEXT, version TEXT, subdir TEXT)
            """
            )
            cursor.execute(
                """
                CREATE INDEX idx_packages_all ON packages (name, version, subdir)
            """
            )

            packages_data = [
                (pkg_info["name"], pkg_info["version"], pkg_info["subdir"])
                for pkg_info in chain(
                    data_noarch["packages"].values(),
                    data_noarch["packages.conda"].values(),
                    data_architecture["packages"].values(),
                    data_architecture["packages.conda"].values(),
                )
            ]

            try:
                conn.execute("BEGIN TRANSACTION")
                cursor.executemany(
                    "INSERT INTO packages (name, version, subdir) VALUES (?, ?, ?)",
                    packages_data,
                )
                conn.commit()
            except sqlite3.Error as e:
                print(f"An error occurred: {e}")
                conn.rollback()
            finally:
                conn.close()

    def pkg_exists(self, requirements: List[str]):
        """Check if the packages exist in conda-forge"""
        import sqlite3

        path_to_db = self._home / "conda-forge.db"
        conn = sqlite3.connect(path_to_db)

        exist_in_conda, not_exist_in_conda = [], []

        requirements_with_exact_version = []
        requirements_with_any_version = []
        requirements_with_unknown_version = []

        for req in requirements:
            parsed = ParsedRequirement(req)

            if parsed.is_exact_version():
                requirements_with_exact_version.append((parsed.name, parsed.version))
            elif parsed.is_any_version():
                requirements_with_any_version.append(req)
            else:
                requirements_with_unknown_version.append(req)

        # Query for requirements with exact version
        if requirements_with_exact_version:
            query_with_exact_version = """
            SELECT name, version FROM packages
            WHERE (name, version) IN ({})
            AND subdir IN ('noarch', ?)
            """
            placeholders = ",".join(["(?, ?)"] * len(requirements_with_exact_version))
            query_with_exact_version = query_with_exact_version.format(placeholders)

            cursor = conn.cursor()
            cursor.execute(
                query_with_exact_version,
                [item for pair in requirements_with_exact_version for item in pair]
                + [self._architecture.value],
            )

            found_with_exact_version = set(cursor.fetchall())

            for name, version in requirements_with_exact_version:
                if (name, version) in found_with_exact_version:
                    exist_in_conda.append(f"{name}={version}")
                else:
                    not_exist_in_conda.append(f"{name}=={version}")

        # Query for requirements with any version
        if requirements_with_any_version:
            query_with_any_version = """
            SELECT DISTINCT name FROM packages
            WHERE name IN ({})
            AND subdir IN ('noarch', ?)
            """
            placeholders = ",".join(["?"] * len(requirements_with_any_version))
            query_with_any_version = query_with_any_version.format(placeholders)

            cursor = conn.cursor()
            cursor.execute(
                query_with_any_version,
                requirements_with_any_version + [self._architecture.value],
            )

            found_with_any_version = set(row[0] for row in cursor.fetchall())

            for req in requirements_with_any_version:
                if req in found_with_any_version:
                    exist_in_conda.append(req)
                else:
                    not_exist_in_conda.append(req)

        not_exist_in_conda.extend(requirements_with_unknown_version)

        conn.close()

        return exist_in_conda, not_exist_in_conda


conda_forge_data = CondaForgeData(architecture=Architecture.LINUX_64)


def requirements_to_environment_yml(requirements_lines: List[str]) -> str:
    """Convert a requirements.txt file to a conda environment.yml file"""
    pkg_names = (line for line in requirements_lines if not line.startswith("#"))
    conda_packages, pip_packages = conda_forge_data.pkg_exists(pkg_names)

    if pip_packages:
        conda_packages.append("pip")
        conda_packages.append({"pip": pip_packages})

    environment = {
        "name": "env",
        "channels": ["conda-forge"],
        "dependencies": conda_packages,
    }

    return yaml.dump(environment)
