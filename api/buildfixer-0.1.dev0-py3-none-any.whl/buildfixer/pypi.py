import requests
from tabulate import tabulate


def get_package_info(package_name, version_prefix=None):
    """
    The function checks for the latest available ploomber version
    uid file doesn't exist.
    """
    response = requests.get(f"https://pypi.org/pypi/{package_name}/json", timeout=1)
    response.raise_for_status()
    data = response.json()

    table_data = []
    headers = [
        "version",
        "comment_text",
        "filename",
        "packagetype",
        "python_version",
        "requires_python",
        "upload_time_iso_8601",
        "yanked_reason",
    ]

    for version, releases in data["releases"].items():
        if version_prefix and not version.startswith(version_prefix):
            continue
        for release in releases:
            row = [version]
            for key in headers[1:]:
                row.append(release.get(key, ""))
            table_data.append(row)

    # Sort the table data by upload_time_iso_8601 in reverse order
    table_data.sort(
        key=lambda x: x[headers.index("upload_time_iso_8601")], reverse=True
    )

    table = tabulate(table_data, headers=headers, tablefmt="grid")
    return table
