import click
from pathlib import Path

from growthcore import io, SETTINGS


@click.group()
def cli():
    """BuildFixer CLI tool."""
    pass


@cli.command()
@click.option(
    "--image-name", default="buildfixer-image", help="Name for the Docker image"
)
def start(image_name: str):
    """
    Start the BuildFixer process with the given requirements file.

    This command builds a Docker image based on the provided requirements
    and runs a container with the specified image name.
    """
    from buildfixer.build import build_image_from_requirements

    requirements_lines = Path("requirements.txt").read_text().splitlines()
    build_image_from_requirements(
        requirements_lines, image_name, path_to_source_code=Path(".").resolve()
    )


@cli.command()
@click.argument("artifact_id", type=str)
def fix(artifact_id: str):
    """
    Fix a failed artifact.
    """
    from growthcore.io import extract_tar_to_temp_dir
    from buildfixer.fixer import build_pack_from_requirements

    path_to_artifact = SETTINGS.PATH_TO_DATA / "jobs" / f"{artifact_id}.tar.gz"
    path_to_staging = SETTINGS.PATH_TO_DATA / "staging"

    with extract_tar_to_temp_dir(
        path_to_staging, f"job_{artifact_id}", path_to_artifact
    ):
        requirements = Path("requirements.txt").read_text()
        build_pack = build_pack_from_requirements(requirements)

        Path("Dockerfile").write_text(build_pack.dockerfile)
        Path("environment.yml").write_text(build_pack.environment_yml)
        Path("requirements.txt").unlink()


@cli.command()
@click.argument("job_id", type=str)
def deploy(job_id: str):
    """
    Deploy an artifact.
    """
    from growthcore.io import extract_tar_to_temp_dir
    from growthtools.storage import JobsStorage
    from growthtools.query import DBDownloader
    from ploomber_cloud.deploy import deploy
    from ploomber_cloud.init import init
    from ploomber_cloud.config import path_to_config

    db_downloader = DBDownloader()
    jobs_storage = JobsStorage()
    job_details = jobs_storage.get_job_details(job_id)
    job_id = job_details["job_id"]

    path_to_artifact = (
        SETTINGS.PATH_TO_DATA / "jobs" / job_details["user_id"] / f"{job_id}.tar.gz"
    )

    path_to_staging = SETTINGS.PATH_TO_DATA / "staging"

    _, _, project_type = db_downloader.get_project_info_from_job_id(job_id)

    with extract_tar_to_temp_dir(
        path_to_staging, f"deploy_{job_id}", path_to_artifact
    ) as path_to_current_dir:

        with path_to_config(path_to_current_dir / "ploomber-cloud.json"):
            init(from_existing=False, force=True, project_type=project_type)
            deploy(watch=False)


@cli.command()
@click.argument("package_name", type=str)
@click.option(
    "--version-prefix", "-v", type=str, default=None, help="Filter by version prefix"
)
def pypi(package_name: str, version_prefix: str):
    """
    Get information about a PyPI package.
    """
    from buildfixer.pypi import get_package_info

    table = get_package_info(package_name, version_prefix)
    click.echo(table)


if __name__ == "__main__":
    cli()
