from pydantic import BaseModel


class BuildPack(BaseModel):
    dockerfile: str
    environment_yml: str
