import shutil
import tempfile
from pathlib import Path
from importlib import resources

from buildfixer import conda, docker, exceptions, fixer
from buildfixer.assets import micromamba


def build_image_from_dockerfile_and_environment(
    dockerfile: str,
    environment_yml: str,
    image_name: str,
    path_to_source_code: str = None,
):
    with tempfile.TemporaryDirectory() as temp_dir:
        temp_dir = Path(temp_dir)

        (temp_dir / "environment.yml").write_text(environment_yml)
        (temp_dir / "Dockerfile").write_text(dockerfile)
        (temp_dir / "bash-profile").write_text(
            resources.read_text(micromamba, "bash-profile")
        )

        if path_to_source_code is not None:
            shutil.copytree(path_to_source_code, temp_dir, dirs_exist_ok=True)

        try:
            docker._build_image_check_output(
                path=str(temp_dir),
                tag=image_name,
                nocache=False,
            )
        except exceptions.DockerBuildError as e:
            e.dockerfile = dockerfile
            e.environment_yml = environment_yml
            raise

    return dockerfile, environment_yml


def build_image_from_requirements(
    requirements_lines: list[str],
    image_name: str,
    path_to_source_code: str = None,
):
    requirements = "\n".join(requirements_lines)
    build_pack = fixer.build_pack_from_requirements(requirements)

    return build_image_from_dockerfile_and_environment(
        build_pack.dockerfile,
        build_pack.environment_yml,
        image_name,
        path_to_source_code,
    )
