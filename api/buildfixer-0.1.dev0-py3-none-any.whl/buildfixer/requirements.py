"""
Utilities for processing requirements.txt files.

Initial code taken from:
https://github.com/ploomber/cloud-backend/blob/main/cloud-core/src/cloud_core/requirements.py
"""

import importlib.util
import re

# https://packaging.pypa.io/en/stable/requirements.html
from packaging.requirements import Requirement


class ParsedRequirement:
    def __init__(self, requirement_string: str):
        self._requirement = Requirement(requirement_string)

    def is_exact_version(self):
        return str(self._requirement.specifier).startswith("==")

    def is_any_version(self):
        return str(self._requirement.specifier) == ""

    @property
    def version(self):
        if self.is_any_version():
            return None

        return str(self._requirement.specifier).split("==")[1]

    @property
    def name(self):
        return self._requirement.name

    @name.setter
    def name(self, value):
        self._requirement.name = value

    def __str__(self):
        return str(self._requirement)


class UnparsedRequirement:
    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name


def _normalize_package_name(pkg):
    return pkg.lower().replace("_", "-")


def _safely_init_requirement_instance(line):
    """
    Initializes a Requirement instance from a line in a requirements.txt file. If
    the line is not a valid requirement, returns None.
    """
    try:
        requirement = ParsedRequirement(line)
    except Exception:
        requirement = UnparsedRequirement(line)
    else:
        requirement.name = _normalize_package_name(requirement.name)

    return requirement


def _init_all_requirements(lines):
    requirements_all = []

    for line in lines:
        line = line.strip()

        if not line:
            continue

        if line.startswith("#"):
            continue

        requirements_all.append(_safely_init_requirement_instance(line))

    return requirements_all


NAME_FIXES_MAPPING = {
    # https://github.com/opencv/opencv-python
    "opencv-python": "opencv-python-headless",
    "sklearn": "scikit-learn",
    "pil": "pillow",
}

# Ensure all keys and values in NAME_FIXES_MAPPING are normalized
for key, value in NAME_FIXES_MAPPING.items():
    normalized_key = _normalize_package_name(key)
    normalized_value = _normalize_package_name(value)
    if key != normalized_key or value != normalized_value:
        raise ValueError(
            f"NAME_FIXES_MAPPING contains non-normalized entries: {key}: {value}"
        )


# this packages cannot be installed in a linux environment
# https://discuss.streamlit.io/t/error-could-not-find-a-version-that-satisfies-the-requirement-pywin32/15343
PACKAGES_TO_REMOVE = {
    "pywin32",
    "pywinpty",
}


def _is_stdlib_package(package_name: str) -> bool:
    """
    Check if a package is part of the Python standard library.

    Parameters
    ----------
    package_name : str
        The name of the package to check.

    Returns
    -------
    bool
        True if the package is part of the standard library, False otherwise.
    """
    spec = importlib.util.find_spec(package_name)
    return (
        spec is not None
        and spec.origin is not None
        and "site-packages" not in spec.origin
    )


class Requirements:
    """Represents and transforms requirements.txt files

    Parameters
    ----------
    requirements_content : str
        The content of the requirements.txt file
    """

    def __init__(self, requirements_content) -> None:
        requirements_obj = _init_all_requirements(requirements_content.splitlines())
        self._name2requirement = {req.name: req for req in requirements_obj}

    def clean(self):
        self.remove_unsupported_packages()
        self.fix_incorrect_names()

    # NOTE: we must ensure that this runs in the same version as the Docker image,
    # as the set of standard library packages can change between Python versions
    def remove_stdlib_packages(self):
        """
        Remove standard library packages from the requirements.txt file.
        """
        for name in list(self._name2requirement.keys()):
            if _is_stdlib_package(name):
                del self._name2requirement[name]

    def remove_unsupported_packages(self):
        """
        Remove unsupported packages from the requirements.txt file.
        """
        for name in list(self._name2requirement.keys()):
            if name in PACKAGES_TO_REMOVE:
                del self._name2requirement[name]

    def fix_incorrect_names(self):
        """
        Fix incorrect names in the requirements.txt file.
        """
        for name, name_fixed in NAME_FIXES_MAPPING.items():
            if name in self._name2requirement:
                self._name2requirement[name_fixed] = self._name2requirement[name]
                self._name2requirement[name_fixed].name = name_fixed
                del self._name2requirement[name]

    def tolines(self):
        """
        Returns the requirements.txt file content as a list of lines.
        """
        return [str(req) for req in self._name2requirement.values()]

    def __str__(self):
        return "\n".join(self.tolines())
