import os
from pathlib import Path


def read_directory_contents(directory_path: str) -> dict:
    """
    Read the contents of a directory and return a dictionary with relative paths as keys
    and file contents as values.

    Args:
        directory_path (str): Path to the directory to read.

    Returns:
        dict: A dictionary where keys are relative file paths and values are file contents or None.
    """
    result = {}
    base_path = Path(directory_path)

    for root, _, files in os.walk(directory_path):
        for file in files:
            file_path = Path(root) / file
            relative_path = file_path.relative_to(base_path).as_posix()

            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                result[relative_path] = content
            except Exception:
                result[relative_path] = None

    return result
