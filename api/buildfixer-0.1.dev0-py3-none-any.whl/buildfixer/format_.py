def format_directory_contents(contents: dict) -> str:
    """
    Format directory contents as a markdown string.

    Parameters
    ----------
    contents : dict
        A dictionary where keys are file paths and values are file contents or None.

    Returns
    -------
    str
        A markdown formatted string of the directory contents.

    Notes
    -----
    This function takes a dictionary representing directory contents and formats it
    into a markdown string. Each file path becomes an H1 heading, and the file contents
    (if not None) are wrapped in a Python code block.

    Examples
    --------
    >>> contents = {
    ...     'file1.py': 'print("Hello, World!")',
    ...     'file2.py': None
    ... }
    >>> print(format_directory_contents(contents))
    # file1.py
    ```python
    print("Hello, World!")
    ```

    # file2.py
    *File content not available*
    """
    markdown = []
    for path, content in contents.items():
        markdown.append(f"# {path}\n")
        if content is not None:
            markdown.append("```python")
            markdown.append(content.strip())
            markdown.append("```\n")
        else:
            markdown.append("*File content not available*\n")

    return "\n".join(markdown)
