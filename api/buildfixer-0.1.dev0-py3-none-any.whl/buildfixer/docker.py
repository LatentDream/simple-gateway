"""
Docker utilities.

Code taken from: https://github.com/ploomber/serverless/blob/main/package/src/serverless/runners.py
"""

from functools import lru_cache
import os
import tarfile
import io
import logging
from pathlib import Path
import io
import tarfile
from contextlib import contextmanager
import itertools
import re
import sys


import docker
from docker.utils.json_stream import json_stream


from buildfixer import exceptions

logger = logging.getLogger(__name__)


IMAGE_PREFIX = "buildfixer"

CURRENT_PYTHON_VERSION = (
    f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
)


@lru_cache(maxsize=1)
def get_docker_client():
    return docker.from_env()


def list_tar_files(tar_contents):
    tar_io = io.BytesIO(tar_contents)

    with tarfile.open(fileobj=tar_io, mode="r:gz") as tar:
        # List the files
        for member in tar.getmembers():
            print(member.name)


def create_tar_from_directory(directory_path):
    """
    Create a tar.gz archive from a directory.

    Parameters:
    -----------
    directory_path : str
        Path to the directory to be archived.

    Returns:
    --------
    bytes
        A bytes object containing the tar.gz archive.
    """
    tar_io = io.BytesIO()

    with tarfile.open(fileobj=tar_io, mode="w:gz") as tar:
        for root, dirs, files in os.walk(directory_path):
            for file in files:
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, directory_path)
                tar.add(file_path, arcname=arcname)

    tar_io.seek(0)
    return tar_io.getvalue()


def run_in_docker_now(
    *,
    cmd,
    dir_to_copy,
    apt_packages=None,
    mem_limit=None,
    environment=None,
    python_version=CURRENT_PYTHON_VERSION,
):
    apt_packages = apt_packages or []
    mem_limit = mem_limit or "4g"
    environment = environment or {}

    path_to_requirements = Path(dir_to_copy, "requirements.txt")

    if path_to_requirements.exists():
        requirements = [
            l
            for l in path_to_requirements.read_text().splitlines()
            if l and not l.startswith("#")
        ]
    else:
        requirements = []

    tag = build_image(requirements, apt_packages, python_version)

    logger.info(f"Starting container with tag: {tag}")

    tar_contents = create_tar_from_directory(dir_to_copy)

    with container_with_image(
        tag,
        mem_limit=mem_limit,
        environment=environment,
    ) as container:
        logger.info("Copying files into container...")
        container.put_archive("/app/", tar_contents)

        # blocking call
        logger.info("Running function...")
        exec_run(container, cmd)
        logger.info("Finished...")


class ExecutionError(Exception):
    def __init__(self, message, exit_code, container_output):
        self.message = message
        self.exit_code = exit_code
        self.container_output = container_output

    def __str__(self):
        return (
            f"{self.message}\nExit code: {self.exit_code}"
            f"\nOutput:\n{self.container_output}"
        )


def exec_run(container, cmd):
    logger.info(f"Running command: {cmd}")

    # to stream and get exit_code, we need to use the low-level API
    # https://github.com/docker/docker-py/issues/1381#issuecomment-523512411
    # https://github.com/docker/docker-py/issues/1989#issuecomment-381304675

    client_low_level = docker.APIClient(base_url="unix://var/run/docker.sock")
    exec_handler = client_low_level.exec_create(container.id, cmd)
    stream = client_low_level.exec_start(exec_handler, stream=True)

    messages = []

    for data in stream:
        # NOTE: this can fail if data isn't utf-8
        # i saw this when trying to run the parse_doc function
        try:
            message = data.decode()
        except UnicodeDecodeError:
            print(f"Failed to decode: {data}")
        else:
            messages.append(message)
            print(f"CONTAINER: {message}", end="")

    messages_ = "".join(messages)
    exit_code = client_low_level.exec_inspect(exec_handler["Id"]).get("ExitCode")

    if exit_code == 137:
        raise ExecutionError("Exceeded memory limit", exit_code, messages_)

    if exit_code:
        raise ExecutionError(f"Command failed: {cmd}", exit_code, messages_)


def _build_image_check_output(
    *, path: str = None, dockerfile: str = None, tag: str, nocache: bool = False
):
    """
    This is a modification of docker.from_env().images.build to allow streaming
    the output
    https://github.com/docker/docker-py/blob/bd164f928ab82e798e30db455903578d06ba2070/docker/models/images.py#L296
    """
    print(f"Building image: {tag}")

    client_high_level = docker.from_env()
    client = docker.APIClient()

    kwargs = dict(tag=tag, nocache=nocache)

    if path:
        kwargs["path"] = path
    elif dockerfile:
        kwargs["fileobj"] = io.BytesIO(dockerfile.encode())
    else:
        raise ValueError("Either path or dockerfile must be provided")

    resp = client.build(**kwargs)

    last_event = None
    image_id = None

    result_stream, internal_stream = itertools.tee(json_stream(resp))

    for chunk in internal_stream:
        for key, value in chunk.items():
            if key == "stream":
                text = value.strip()
                if text:
                    print(text)

        if "error" in chunk:
            raise exceptions.DockerBuildError(chunk["error"])

        if "stream" in chunk:
            match = re.search(
                r"(^Successfully built |sha256:)([0-9a-f]+)$", chunk["stream"]
            )
            if match:
                image_id = match.group(2)
        last_event = chunk

    if image_id:
        return (client_high_level.images.get(image_id), result_stream)

    raise exceptions.DockerBuildError(last_event or "Unknown")


def read_from_container(container, path):
    bits, stat = container.get_archive(path)

    bits_io = io.BytesIO()

    for chunk in bits:
        bits_io.write(chunk)

    bits_io.seek(0)

    tar = tarfile.open(fileobj=bits_io, mode="r")
    file = tar.extractfile(stat["name"])
    contents = file.read()
    return contents


@contextmanager
def container_with_image(
    image_name,
    cpu_count=4,
    mem_limit="4g",
    volumes=None,
    working_dir="/app",
    environment=None,
    ports=None,
):
    client = docker.from_env()

    environment = environment or {}
    kwargs = dict(environment=environment)

    container = client.containers.run(
        image_name,
        detach=True,
        command=["sleep", "infinity"],
        cpu_period=100000,
        cpu_quota=int(cpu_count * 100000),
        volumes=volumes,
        working_dir=working_dir,
        mem_limit=mem_limit,
        ports=ports,
        **kwargs,
    )

    print(f"Spinning up container: {image_name}")

    try:
        yield container
    finally:
        # Code to clean up the resource or perform actions after leaving the context
        print(f"Shutting down container: {image_name}")
        container.kill()
        container.remove()


def docker_run(image_name: str, command: str) -> tuple[int, str, str]:
    """
    Execute a command in a Docker container and return the exit code, output, and error.

    Parameters:
    -----------
    client : docker.client.DockerClient
        The Docker client instance.
    image_name : str
        The name of the Docker image to use.
    command : str
        The command to run in the container.

    Returns:
    --------
    tuple[int, str, str]
        A tuple containing the exit code, output, and error of the command.
    """

    try:
        container = get_docker_client().containers.run(image_name, command, detach=True)
        result = container.wait()
        exit_code = result["StatusCode"]
        output = container.logs(stdout=True, stderr=False).decode("utf-8")
        error = container.logs(stdout=False, stderr=True).decode("utf-8")
        return exit_code, output, error
    finally:
        try:
            container.remove(force=True)
        except Exception:
            pass  # If we can't remove the container, we've done our best


def docker_check_output(image_name: str, command: str) -> str:
    """
    Run a command in a Docker container and return the output.

    Parameters:
    -----------
    image_name : str
        The name of the Docker image to use.
    command : str
        The command to run in the container.

    Returns:
    --------
    str
        The output of the command.

    Raises:
    -------
    Exception
        If an error occurs during container execution or if the command exits with a non-zero code.
    """
    try:
        exit_code, output, error = docker_run(image_name, command)

        if exit_code != 0:
            raise Exception(
                f"Command failed with exit code {exit_code}. Output: {output}. Error: {error}"
            )

        return output

    except docker.errors.ContainerError as e:
        raise Exception(f"Error running command in container: {str(e)}")
    except docker.errors.ImageNotFound:
        raise Exception(f"Docker image '{image_name}' not found")
    except Exception as e:
        raise Exception(f"An unexpected error occurred: {str(e)}")
