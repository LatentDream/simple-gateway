class DockerBuildError(Exception):
    dockerfile: str = None
    environment_yml: str = None

    def __init__(self, message):
        super().__init__("[DOCKER BUILD] " + message)
