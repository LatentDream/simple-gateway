import copy


from openai import OpenAI

from buildfixer import format_
from buildfixer.models import BuildPack

from functools import lru_cache


@lru_cache(maxsize=1)
def get_openai_client():
    return OpenAI()


SYSTEM_PROMPT_BASE = """
You are a helpful assistant that can fix build errors.

You'll be given the contents of a Dockerfile, a conda environment.yml file, and the
error message.

You'll need to return a new Dockerfile and environment.yml file that fix the build
error.
"""


def fix_build_with_ai(
    *, error_message: str, dockerfile: str, environment_yml: str
) -> BuildPack:
    SYSTEM_PROMPT = copy.deepcopy(SYSTEM_PROMPT_BASE)

    completion = get_openai_client().beta.chat.completions.parse(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Dockerfile: {dockerfile}"},
            {"role": "user", "content": f"environment.yml: {environment_yml}"},
            {"role": "user", "content": f"Error: {error_message}"},
        ],
        response_format=BuildPack,
    )

    build_pack = completion.choices[0].message.parsed

    return build_pack


def fix_build(
    *, error_message: str, dockerfile: str, requirements_txt: str
) -> BuildPack:
    """
    Use a combination of rules and AI to fix the build error.
    """
    # NOTE: this will be the entrypoint
    # cases:
    # - non-docker app: see if the model can fix the issue by updating the requirements.txt
    #   if not, then we need to upgrade the app to a docker app and use the heuristics
    #   to get the Dockerfile and environment.yml, then pass this to the AI
    # - docker app: these will be more challenging as having a Dockerfile gives a lot
    #   of flexibility. perhaps we can ask the AI to merge the user's Dockerfile with
    #   our Dockerfile + environment.yml, then apply the rules to the merged file.
