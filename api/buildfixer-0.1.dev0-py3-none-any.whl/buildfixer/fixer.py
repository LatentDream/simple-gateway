from importlib import resources

from buildfixer.assets import micromamba
from buildfixer.models import BuildPack
from buildfixer.requirements import Requirements
from buildfixer.conda import requirements_to_environment_yml


def build_pack_from_requirements(requirements_content: str) -> BuildPack:
    requirements = Requirements(requirements_content)
    requirements.clean()

    environment_yml = requirements_to_environment_yml(requirements.tolines())
    dockerfile = resources.read_text(micromamba, "Dockerfile")

    return BuildPack(dockerfile=dockerfile, environment_yml=environment_yml)
